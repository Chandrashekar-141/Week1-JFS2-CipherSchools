import java.util.Scanner;

public class Test5 {
	private static final String True = null;
	private static final String False = null;

	public static void main(String[] args) {
		/* Problem Statement:
		 
		 * Assuming you are Riding a Bike and POlice Officer Stops you
		Police officer asking you to provide 2 Details
		Your Speed
		if it is your birthday today?
        The police officer will calculate fine based on the following parameters
        If it is your Birthday You willl be Waived off(Exempted) with
        5Miles/Hour
        
        If it is not your Birthday No Exemption will be GIven
        //If your Speed is Grater than 80 Ticket raised will be 'High Ticket'
        //If Your Speed in between 60 and 80 Ticket raised will be 'Mid Ticket'
        // If Your Speed is below 60 Ticket Raised will be No Ticket.
        
        // Find The Ticket!!!
        
        */
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Speed: ");
		int speed= sc.nextInt();
				
		
		
		System.out.println("Today is Your Birthday :");
		boolean is_birthday=sc.nextBoolean();
		
		if(is_birthday==true) {
			speed= speed-5;//or speed-=5
		}
	if(speed>80)
		System.out.println("High ticket");
	if(speed >=60 && speed<= 80)
		System.out.println("Mid Ticket");
	if(speed<60)
		System.out.println("No Ticket");
			
			
		}	
	}

