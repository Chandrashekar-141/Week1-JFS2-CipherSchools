import java.util.*;
public class Test4 {
	public static void main(String[] args) {
		
		
		//Title:How long is your BURRRRP?
		//Ask the user to enter an integer (burp Length)
		//Depending on the input provided'Burp'will be Produced
	    
		//For Example :
		//5 : 'Burrrrp'
		
		//25: 'Burrrrrrrrrrrrrrrrrrrp'
	   // 40: 'Burrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrp'
		
	//Input can be any Random Number....
	Scanner sc = new Scanner(System.in);
	System.out.println("How long is your Burp?");
	int burpLength = sc.nextInt();
	
	String msg="";
	
	for(int i=1;i<=burpLength;i++) {
		msg=msg+"r"; //can also be written as msg+="r"
	}
	System.out.println("Bu"+msg+"p");
	
	
	}
}

//if BurpLength is 4
/* r = ''+r
 * rr = r+r
 * rrr = rr+r
 * rrrr= rrr+r
 */
