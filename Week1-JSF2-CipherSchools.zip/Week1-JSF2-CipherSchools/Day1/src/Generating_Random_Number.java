import java.util.Random;
import java.util.*;

public class Generating_Random_Number {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Random rnd =new Random();
		int computerchoice = rnd.nextInt(20);
		System.out.println("Computer Choice : " +computerchoice);
		
		
	//Guess the number
		
		
		for(int i=1; i<6;i++) {
			
	System.out.println("Guess the number between 0 to 20 ");
	int userInput = sc.nextInt();
	
	if(userInput>computerchoice) {
		System.out.println("Your Guess is Too High");
	}
	else if(userInput< computerchoice){
		System.out.println("Your Guess is Too Low");
		
	}
	else {
		System.out.println("Gotcha! Your Guess is Correct!!20");
		break;
	}
	}}
}


