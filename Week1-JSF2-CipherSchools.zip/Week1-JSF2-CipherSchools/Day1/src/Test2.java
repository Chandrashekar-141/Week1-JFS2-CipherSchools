
public class Test2 {
	public static void main(String[] args) {
		
		char ch='A'; //65
		
		
		while(ch<=90) {
			System.out.print(ch+" ");
			ch++;
		}
		//Do While
		char ch1='A';
		do {
			System.out.print(ch+" ");
		ch++;
		}while(ch<='Z');
	}	

}
