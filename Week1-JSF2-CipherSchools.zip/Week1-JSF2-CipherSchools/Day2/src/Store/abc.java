package Store;

import Inventory.*;
public class abc extends Stock {
	void foo() {
		
		
	}

}
