package Inventory;

public class Stock {
	public String iAmAccesibleEverywhere;
	
	private String iAmAccesibleOnlyHere;
	
	protected String iAmAccesibletoDerivedClass;
	
	String iAmAccesibletoALLClassInSamePackage;
}


