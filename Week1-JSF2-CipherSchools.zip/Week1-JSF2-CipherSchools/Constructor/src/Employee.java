
public class Employee {

	//constructor
	/*
	 * How to Identify a Constructor:
	 * 1.1 same name as class
	 * 1.2 No return type
	 */
	/* <Purpose>
	 * 1.1  it creates/initializes Object in Memory(RAM)
	 * 1.2 You can use Constructor Block to initialize some defaults values.
	 */
	
	int EmployeeId;
	int salary;
	String dept;
	
	
	Employee(int empId, int sal, String d){
	 EmployeeId= empId;
	 salary=sal;
	 dept = d;
	}
	public static void main(String[] args) {
		
		
		Employee harsha = new Employee(101,3000,"Testiing");
		Employee varsha = new Employee(102,5000,"Engineering");
		System.out.println(harsha.EmployeeId+" salary"+harsha.salary+"Dept "+harsha.dept);
		System.out.println(varsha.EmployeeId+" salary"+varsha.salary+"Dept "+varsha.dept);
	}
	
	
}
