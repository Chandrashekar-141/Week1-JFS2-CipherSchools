//Inheritance

/*1.1 Memory Usage Optimization
 * 1.2 Code Reusability
 *  	--faster development
 *  	--central code(Easy to debug/test).
 *  Increases(Productivity/Efficiency)
 */
public class Furniture {
	
	int width;
	int height;
	
void display(String item) {
	System.out.println(item+"Width"+width+"Height"+height);
}
public static void main(String[] args) {
	
	Chair neelkamal = new Chair();
	neelkamal.foo();
}
	
	
}
class Chair extends Furniture{
	
	void foo() {width=10;height=20;display("chair");}	
	}

class Table extends Furniture{
	
	void foo() {width=10;height=20;display("Table");}	
	
	
}
class Almira extends Furniture{
	
	void foo() {width=10;height=20;display("Almira");}	
	
	
}


//--complexity : Memory Occupied = n*8 bytes here nis count of classes.